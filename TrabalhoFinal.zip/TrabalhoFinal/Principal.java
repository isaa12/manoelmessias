import java.util.Scanner;
public class Principal {
    public static void main(String[] args) {
        // criar objetos do tio ContaCorrente e ContaPoupanca e atribuir valores aos atributos utilizando os metodos se
        ContaCorrente cc1 = new ContaCorrente();
        ContaPoupanca cp1 = new ContaPoupanca();
        //setando os valores da conta corrente
        cc1.setNumero(001);
        cc1.setNome("João");
        cc1.setSaldo(1000);
        cc1.setSenha("1234");
        cc1.setLimite(1000);

        cp1.setNumero(002);
        cp1.setNome("Maria");
        cp1.setSaldo(1000);
        cp1.setSenha("1234");
        cp1.setDiaAniversario(10);

        Scanner entrada = new Scanner(System.in);


        //depositar um valor na conta corrente
        System.out.println("Digite o número da conta:");
        int numero = entrada.nextInt();
        if(numero==cc1.getNumero()){
            System.out.println("Conta válida!");
            System.out.println("Digite o valor do depósito:");
            double valor = entrada.nextDouble();
            cc1.depositar(valor);
            System.err.println("Deposito realizado com sucesso!");
            System.out.println("O novo saldo é:"+cc1.getSaldo());
        }
        else{
            System.out.println("Conta é inválida!");
        }
        entrada.close();
    }

}
